This folder contains scripts that should never need to be amended by the end user.

Please DO NOT CHANGE THESE FILES unless you are sure you know what you are doing!!!
